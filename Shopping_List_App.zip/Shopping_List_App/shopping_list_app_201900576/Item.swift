import CoreData

@objc(Item)
class Item: NSManagedObject{
    
    @NSManaged var id: NSNumber!
    @NSManaged var title: String!
    @NSManaged var  quantity: Int
    @NSManaged var price: Double
    @NSManaged var note: String!
    @NSManaged  override var isDeleted: Bool
    @NSManaged var category: String!
    
    static func == (lhs: Item, rhs: Item) -> Bool {
        return lhs.category == rhs.category}
    
}

