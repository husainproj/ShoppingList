import UIKit

class ItemCell:UITableViewCell{
    
   
    
    @IBOutlet weak var titleLabel: UILabel!
    
    

    
    @IBOutlet weak var noteField: UILabel!
    
}
