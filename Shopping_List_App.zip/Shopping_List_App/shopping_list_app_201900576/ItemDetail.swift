
import UIKit
import CoreData


class ItemDetail: UIViewController {

    var selectedItemEdit: Item? = nil
    
    @IBAction func saveAction(_ sender: Any) {
        
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context:  NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        if(selectedItemEdit == nil){
            
            
            
            let entity = NSEntityDescription.entity(forEntityName: "Item", in: context)
            let newItem = Item(entity: entity!, insertInto: context)
            newItem.id = itemlist.count as NSNumber
            
            
            // checking if the user is entering an item name or no
            
            if titleField.text == ""{
                
                
                
                
                let alert = UIAlertController(title: "Alert", message: "Your Item was not stored", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true,completion: nil)
                
            }else{
                newItem.title = titleField.text
                
                newItem.category = navigationItem.title!
                newItem.note = noteField.text
                
                if quantityField.text == "" {
                    newItem.quantity = 0
                }else {
                    
                    newItem.quantity = Int(quantityField.text!)!
                }
                
                if priceField.text == ""{
                    newItem.price = 0.0
                }else {
                    
                    newItem.price = Double(priceField.text!)!+0.0
                }
                do{
                    try context.save()
                    itemlist.append(newItem)
                    navigationController?.popViewController(animated: true)
                    
                }
                catch{
                    
                    print("context save error")
                }
            }
            
        }
        else {
            // edit item
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
            
            do{
                let results:NSArray = try context.fetch(request) as NSArray
                for result in results {
                    
                    let item = result as! Item
                    if(item == selectedItemEdit){
                        item.title = titleField.text
                        item.note = noteField.text
                        item.quantity = Int(quantityField.text!)!
                        item.price = Double(priceField.text!)!+0.0
                        item.category = navigationItem.title
                        try context.save()
                        navigationController?.popViewController(animated: true)
                        
                        
                    }
                }
                
            }catch{
                
                print("Fetch Failed")
            }
            
        }
        
        
        
        
    }
    @IBOutlet weak var titleField: UITextField!
    
  
    
    @IBOutlet weak var priceField: UITextField!
    @IBOutlet weak var quantityField: UITextField!
   
    @IBOutlet weak var noteField: UITextView!
    override func viewDidLoad() {
        
        titleField.becomeFirstResponder()
        
        super.viewDidLoad()
        if(selectedItemEdit != nil){
            
            
            titleField.text = selectedItemEdit?.title
            quantityField.text = String(selectedItemEdit!.quantity)
            priceField.text = String(selectedItemEdit!.price)
            noteField.text = selectedItemEdit?.note
            
            
        }
        
    }


}

