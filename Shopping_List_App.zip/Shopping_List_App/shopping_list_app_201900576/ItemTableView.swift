import UIKit
import CoreData

var itemlist = [Item]()
class ItemTableView: UITableViewController{
  
    
    

    
    
    var firstLoad = true
    // fetch the data from the datacore
    override func viewDidLoad() {
        //if(firstLoad){
            
            firstLoad = false
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context:  NSManagedObjectContext = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
            
            let category = navigationItem.title
            let predicate = NSPredicate(format: "category = %@", category!)
            request.predicate = predicate
            do{
                let results:NSArray = try context.fetch(request) as NSArray
                
                for result in results {
                    
                    let item = result as! Item
                    
                    itemlist.append(item)
                    
                    
                    
                }
                
            }catch{
                
                print("Fetch Failed")
           }
        //}
    }
    
        
    
    
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let itemcell = tableView.dequeueReusableCell(withIdentifier: "itemCellID", for: indexPath) as! ItemCell
        
        let thisItem: Item!
        thisItem = itemlist[indexPath.row]
        
        itemcell.titleLabel?.text = thisItem.title
        
        
        itemcell.noteField?.text = thisItem.note
        
        return itemcell
    }
    
    
    
    
    

    
    
   override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return itemlist.count

    }
    
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    // sends the data to the ViewDetail Controller
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "viewItem", sender: self)
            
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "viewItem"){
            
            let indexPath = tableView.indexPathForSelectedRow!
            
            let itemDetail = segue.destination as? ViewDetail
            
            
            
            let selectedItem : Item!
                
                
            selectedItem = itemlist[indexPath.row]
            
            itemDetail!.selectedItem = selectedItem
            
            
            tableView.deselectRow(at: indexPath, animated: true)
        }
        
        if(segue.identifier == "newItem"){
            let sourceViewController = segue.source as! ItemTableView
            let category = sourceViewController.navigationItem.title
            
            
            
//            let indexPath = tableView.indexPathForSelectedRow!
//
            let destination = segue.destination as? ItemDetail
            
            //let list = lists[indexPath.row]
            
            destination?.navigationItem.title = category
            
            
            
        }
            
        }
        
        
        
        
        
     
    // Swipe action for the delete
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .destructive, title: "Delete"){(action,view,completionHandler)in

            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context:  NSManagedObjectContext = appDelegate.persistentContainer.viewContext
            
            //delete the data
            
            let deleteitem = itemlist[indexPath.row]

            context.delete(deleteitem)
            // and removing the row in table
            itemlist.remove(at: indexPath.row)
            
            
            
            
            // save the data
            
            do{
            try    context.save()
            }catch{
            }
            
            // reloading the table
            
           tableView.reloadData()
            
            
           
            
            
            

        }
        
    return UISwipeActionsConfiguration(actions: [action])
        
        
        
        
    }

    
}

    
    

