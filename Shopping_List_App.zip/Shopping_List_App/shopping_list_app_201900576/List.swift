//
//  List.swift
//  shopping_list_app_201900576
//
//  Created by administrator on 11/01/2023.
//

import Foundation
import UIKit

struct List: Equatable, Codable{
    let id = UUID()
    var title: String
    
    static let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    
    static let archiveURL = documentsDirectory.appendingPathComponent("lists").appendingPathExtension("plist")
    
    static func ==(lhs: List, rhs: List) -> Bool {
        return lhs.id == rhs.id
    }
    
    static func loadLists() -> [List]? {
        guard let codedLists = try? Data(contentsOf: archiveURL) else {return nil}
        let propertyListDecoder = PropertyListDecoder()
        return try? propertyListDecoder.decode(Array<List>.self, from: codedLists)
    }
    
    static func saveLists(_ lists: [List]){
        let propertyListEncoder = PropertyListEncoder()
        let codedLists = try? propertyListEncoder.encode(lists)
        try? codedLists?.write(to: archiveURL, options: .noFileProtection)
    }
    
    static func loadSampleLists() -> [List]{
        let list1 = List(title: "Groceries")
        let list2 = List(title: "Electronics")
        
        return [list1, list2]
    }
}
