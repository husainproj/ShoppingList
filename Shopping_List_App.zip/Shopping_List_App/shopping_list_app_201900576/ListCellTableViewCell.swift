//
//  ListCellTableViewCell.swift
//  shopping_list_app_201900576
//
//  Created by administrator on 11/01/2023.
//

import UIKit

class ListCellTableViewCell: UITableViewCell {
    
    
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var editButton: UIButton!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    }
   
    

    
    
    

