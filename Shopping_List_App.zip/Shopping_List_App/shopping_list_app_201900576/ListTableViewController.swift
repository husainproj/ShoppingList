//
//  ListTableViewController.swift
//  shopping_list_app_201900576
//
//  Created by administrator on 11/01/2023.
//

import Foundation
import UIKit

class ListTableViewController: UITableViewController{
    
    var lists = [List]()
    
    
    
    @IBSegueAction func editToDo(_ coder: NSCoder, sender: Any?) -> NewListTableViewController? {
        guard let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) else {
            return nil
    }

        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let detailController = NewListTableViewController(coder: coder)
        detailController?.list = lists[indexPath.row]
        
        return detailController
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        if let savedLists = List.loadLists(){
            lists = savedLists
        }else{
            //lists = List.loadSampleLists()
        }
        
        navigationItem.leftBarButtonItem = editButtonItem
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToItem"{
            let indexPath = tableView.indexPathForSelectedRow!
           
            let destination = segue.destination as? ItemTableView
            
            let list = lists[indexPath.row]
            
            destination?.navigationItem.title = list.title
            
            
            
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lists.count
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            lists.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            List.saveLists(lists)
        }
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCellIdentifier", for: indexPath) as! ListCellTableViewCell
        
        let list = lists[indexPath.row]
        cell.nameLabel?.text = list.title
        
        return cell
        
    }
    
    @IBAction func unwindToList(segue: UIStoryboardSegue){
        guard segue.identifier == "saveButton" else { return }
        let sourceViewController = segue.source as! NewListTableViewController
        
        if let list = sourceViewController.list {
            if let indexOfExistingList = lists.firstIndex(of: list) {
                lists[indexOfExistingList] = list
                tableView.reloadRows(at: [IndexPath(row: indexOfExistingList, section: 0)], with: .automatic)
            } else {
                let newIndexPath = IndexPath(row: lists.count, section: 0)
                lists.append(list)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }
        List.saveLists(lists)
    }
    
}
