//
//  NewListTableViewController.swift
//  shopping_list_app_201900576
//
//  Created by administrator on 11/01/2023.
//

import Foundation
import UIKit

class NewListTableViewController: UITableViewController{
  
    @IBOutlet var saveButton: UIBarButtonItem!
    @IBOutlet var nameTextField: UITextField!
    
    var list: List?
    
    @IBAction func textEditingChanged(_ sender: UITextField) {
        updateSaveButtonState()
    }
    @IBAction func returnKeyPressed(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let list = list {
            navigationItem.title = "Name"
            nameTextField.text = list.title
        }
        updateSaveButtonState()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        guard segue.identifier == "saveButton" else {return}
        
        let title = nameTextField.text!
        
        if list != nil {
            list?.title = title
        } else {
            list = List(title: title)
        }
        
    }
    
    func updateSaveButtonState(){
        let shouldEnableSaveButton = nameTextField.text?.isEmpty == false
        
        saveButton.isEnabled = shouldEnableSaveButton
        
    }
    
   
    
    
}
