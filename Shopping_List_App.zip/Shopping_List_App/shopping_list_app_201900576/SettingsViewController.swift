//
//  SettingsViewController.swift
//  shopping_list_app_201900576
//
//  Created by Hussain Mansoori on 11/01/2023.
//

import Foundation
import UserNotifications
import UIKit
class SettingsViewController: UIViewController {
    
    //@IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var darkModeSwitch: UISwitch!
    @IBOutlet weak var notificationSwitch: UISwitch!
    
    //let reminderCenter = UNUserNotificationCenter.current()
    override func viewDidLoad() {
        super.viewDidLoad()
        //        reminderCenter.requestAuthorization(options: [.alert, .sound]){
        //            (permissionGranted, error)in
        //            if(!permissionGranted){
        //                print("Permission Denied")
        //            }
        //        }
        darkModeSwitch.isOn = false
        notificationSwitch.isOn = false
    }
    
    @IBAction func changedValue(_ sender: Any) {
        if darkModeSwitch.isOn == false{
            let window = UIApplication.shared.windows[0]
            window.overrideUserInterfaceStyle = .light
        }
        else{
            let window = UIApplication.shared.windows[0]
            window.overrideUserInterfaceStyle = .dark
        }
        
    }
    
    @IBAction func notifSwitchChanged(_ sender: Any) {
        if notificationSwitch.isOn == false{
            //nothing will happen if it is closed
        }
        else{
            let center = UNUserNotificationCenter.current()
            
            center.requestAuthorization(options: [.alert, .sound]){
                (granted, error) in
                
            }
            
            let content1 = UNMutableNotificationContent()
            content1.title = "Do you want to add new list!"
            content1.body = "Or make changes for your lists!"
            
            let date1 = Date().addingTimeInterval(15)
            //it should be for a day(86400)
            
            let dateComponents1 = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date1)
            
            let trigger1 = UNCalendarNotificationTrigger(dateMatching: dateComponents1, repeats: true)
            
            let uuidString = UUID().uuidString
            
            let request1 = UNNotificationRequest(identifier: uuidString, content: content1, trigger: trigger1)
            
            center.add(request1){
                (error) in
            }
        }
    }
    
}
