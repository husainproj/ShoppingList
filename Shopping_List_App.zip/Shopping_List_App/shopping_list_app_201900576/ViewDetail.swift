import UIKit
import CoreData

class ViewDetail: UIViewController{
    var selectedItem: Item? = nil
    
    

    @IBOutlet weak var viewItem: UILabel!

    @IBOutlet weak var viewQuantity: UILabel!
    
    
    @IBAction func editAction(_ sender: Any) {
        
        performSegue(withIdentifier: "editItem", sender: self)

        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let itemdata = segue.destination as! ItemDetail
        itemdata.selectedItemEdit = selectedItem
        
    }
   
    
   
    @IBOutlet weak var viewPrice: UILabel!
    
    
    @IBOutlet weak var viewNote: UILabel!
    
    
    override func viewDidLoad() {

        super.viewDidLoad()
    }
    
    // reloads the data after updating it
    override func viewWillAppear(_ animated: Bool) {
        if(selectedItem != nil){
            
            
            viewItem.text = selectedItem?.title
            viewQuantity.text = String(selectedItem!.quantity)
            viewPrice.text = String(selectedItem!.price)
            viewNote.text = selectedItem?.note
            
            
        }
    }
    

}
